# Django Studio: Brand Component Library Setup

## Overview

This scaffold integrates four libraries into your `publishing_api/` Django Studio:

1. **django-cotton**: HTML-first declarative components (`<c-card>`, `<c-field>`)
2. **django-template-partials**: Named template fragments for HTMX responses
3. **django-tailwind**: Your existing Tailwind tokens in Django templates
4. **django-crispy-forms** + custom `studio` template pack: Brand-consistent form rendering

## Installation

```bash
cd publishing_api
pip install django-cotton django-template-partials django-tailwind django-crispy-forms
```

## Settings (config/settings.py)

Add to INSTALLED_APPS:

```python
INSTALLED_APPS = [
    # ... existing apps ...
    "django_cotton",
    "template_partials",
    "tailwind",
    "crispy_forms",

    # Your custom crispy template pack
    "crispy_studio",

    # Tailwind app (created by `python manage.py tailwind init`)
    "theme",
]

# Crispy Forms: use your custom brand template pack
CRISPY_TEMPLATE_PACK = "studio"

# Tailwind
TAILWIND_APP_NAME = "theme"
```

## Tailwind Init

```bash
python manage.py tailwind init
# Name the app "theme" when prompted

# Then in theme/static_src/tailwind.config.js,
# paste the config from tailwind.config.js in this scaffold.
```

## File Placement

```
publishing_api/
├── cotton_components/         ->  publishing_api/templates/cotton/
│   ├── card.html
│   ├── field.html
│   ├── badge.html
│   ├── section_label.html
│   ├── toast.html
│   ├── btn.html
│   └── stage_pill.html
├── crispy_studio/             ->  publishing_api/crispy_studio/
│   ├── __init__.py
│   └── templates/studio/
│       ├── layout/
│       │   └── fieldset.html
│       ├── field/
│       │   ├── field.html
│       │   └── errors.html
│       └── widget/
│           ├── input.html
│           ├── textarea.html
│           └── select.html
└── static/css/
    └── studio-tokens.css      ->  publishing_api/static/css/studio-tokens.css
```

## Dev Server

```bash
# Terminal 1: Django
python manage.py runserver

# Terminal 2: Tailwind watcher
python manage.py tailwind start
```
