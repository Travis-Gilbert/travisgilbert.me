# Django Studio: Brand Component Library

A component system for your `publishing_api/` Django Studio that matches the
travisgilbert.com design language. Four libraries, zero styling conflicts.

## Architecture

```
                    ┌──────────────────────────────────────┐
                    │           BRAND TOKENS                │
                    │  tailwind.config.js + studio-tokens.css│
                    └────────┬───────────────┬─────────────┘
                             │               │
                    ┌────────▼──────┐  ┌─────▼────────────┐
                    │ django-cotton  │  │ crispy-forms      │
                    │ (components)   │  │ (form rendering)  │
                    │                │  │                   │
                    │ <c-card>       │  │ Fieldset layout   │
                    │ <c-badge>      │  │ Field wrappers    │
                    │ <c-btn>        │  │ Widget templates  │
                    │ <c-toast>      │  │                   │
                    │ <c-stage_pill> │  │ studio/ pack      │
                    │ <c-field>      │  │                   │
                    │ <c-section_..> │  │                   │
                    └───────┬───────┘  └────────┬──────────┘
                            │                   │
                    ┌───────▼───────────────────▼──────────┐
                    │       django-template-partials         │
                    │                                       │
                    │  {% partialdef stage_display inline %} │
                    │  {% partialdef essay_form inline %}    │
                    │                                       │
                    │  Named fragments for HTMX responses   │
                    └───────────────────────────────────────┘
```

## What Each Library Does

### django-cotton (components)
HTML-first components that live in `templates/cotton/`. Write `<c-card grid>`
instead of copy-pasting div soup. Cotton handles slot projection, boolean
props, and attribute passthrough. No Python needed for component definitions.

### django-template-partials (HTMX fragments)
Define named regions in your full-page templates. When an HTMX request
comes in, render just the partial instead of the whole page. No separate
partial template files cluttering your directory.

### django-tailwind (token bridge)
Runs Tailwind's build process inside Django's dev server. Your brand tokens
(terracotta, parchment, Vollkorn, warm shadows) work as utility classes
in Django templates, keeping both codebases visually identical.

### django-crispy-forms + studio pack (form rendering)
The `studio` template pack renders every form element with your brand
styling: Vollkorn labels, Courier Prime hints, warm parchment inputs,
terracotta focus rings, section-colored fieldsets. Define the layout in
Python (FormHelper), render in templates with `{% crispy form %}`.

## Quick Start

```bash
cd publishing_api

# 1. Install
pip install django-cotton django-template-partials django-tailwind django-crispy-forms

# 2. Init Tailwind
python manage.py tailwind init  # name it "theme"

# 3. Copy files from this scaffold:
#    - tailwind.config.js       -> theme/static_src/tailwind.config.js
#    - static/css/studio-tokens.css -> static/css/studio-tokens.css
#    - cotton_components/*.html  -> templates/cotton/
#    - crispy_studio/            -> crispy_studio/ (as a Django app)

# 4. Update config/settings.py (see SETUP.md)

# 5. Run both servers
python manage.py tailwind start  # Terminal 1
python manage.py runserver       # Terminal 2
```

## Component Reference

### `<c-card>`
| Prop    | Type   | Options                                              |
|---------|--------|------------------------------------------------------|
| variant | str    | tint-terracotta, tint-teal, tint-gold, dark, plain   |
| grid    | bool   | Blueprint grid overlay                               |
| hover   | bool   | Lift on hover (for clickable cards)                  |
| href    | str    | Wraps card in anchor tag                             |

### `<c-section_label>`
| Prop  | Type | Options                    |
|-------|------|----------------------------|
| color | str  | terracotta, teal, gold     |

### `<c-badge>`
| Prop    | Type | Options                                      |
|---------|------|----------------------------------------------|
| color   | str  | terracotta, teal, gold, success, error, ink  |
| outline | bool | Outline variant instead of filled            |

### `<c-btn>`
| Prop    | Type | Options                              |
|---------|------|--------------------------------------|
| variant | str  | primary, secondary, ghost, danger    |
| type    | str  | button, submit                       |
| href    | str  | Renders as anchor                    |

### `<c-toast>`
| Prop    | Type | Options               |
|---------|------|-----------------------|
| type    | str  | success, error, info  |
| message | str  | Display text          |
| commit  | str  | Commit URL link       |

### `<c-stage_pill>`
| Prop         | Type | Options                                          |
|--------------|------|--------------------------------------------------|
| stage        | str  | drafting, revising, ready, published, archived   |
| interactive  | bool | Show HTMX stage-change dropdown                 |
| content_type | str  | URL content type slug                            |
| slug         | str  | Content slug                                     |

### `<c-field>`
| Prop     | Type | Description            |
|----------|------|------------------------|
| label    | str  | Field label            |
| hint     | str  | Help text              |
| error    | str  | Error message          |
| required | bool | Required asterisk      |

## Crispy Fieldset Colors

Map each content type to its section color:

```python
# Essays: terracotta
Fieldset("Metadata", "title", "slug", css_class="section-terracotta")

# Field Notes: teal
Fieldset("Observation", "title", "date", css_class="section-teal")

# Projects: gold
Fieldset("Details", "title", "role", css_class="section-gold")

# Add blueprint grid to any fieldset
Fieldset("SEO", "tags", "description", css_class="section-teal with-grid")
```

## Brand Rules Enforced

These components enforce your design doc constraints:

| Rule                          | How It's Enforced                          |
|-------------------------------|--------------------------------------------|
| No white backgrounds          | All surfaces use cream/parchment tokens    |
| Warm shadows, not gray        | shadow-warm-* uses rgba(42,36,32,...)      |
| Monospace for labels/technical| font-mono (Courier Prime) on all labels    |
| Terracotta = essays           | section-terracotta class on essay fieldsets |
| Teal = field notes            | section-teal class on field note fieldsets  |
| Gold = projects               | section-gold class on project fieldsets     |
| No colons in code/content     | CSS classes use hyphens, not colons        |
| Radix-style headless approach | Cotton components have zero default CSS    |
