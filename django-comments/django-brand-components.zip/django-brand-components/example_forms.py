"""
Example: Wiring crispy-forms helpers into your existing editor forms.

This shows how to add FormHelper + Layout to EssayForm as a reference.
Apply the same pattern to your other forms (FieldNoteForm, ProjectForm, etc.).

The key idea: each Fieldset gets a css_class that maps to a section color.
The `studio` template pack reads that class and renders the colored
section label + optional blueprint grid.
"""

from crispy_forms.helper import FormHelper
from crispy_forms.layout import Fieldset, Layout, Submit, HTML

from apps.editor.forms import EssayForm  # your existing form


class BrandEssayForm(EssayForm):
    """
    EssayForm with crispy helper for brand-consistent rendering.

    In your template, replace manual field rendering:
        {% load crispy_forms_tags %}
        {% crispy form %}

    Instead of:
        {{ form.title }}
        {{ form.body }}
        ...
    """

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.helper = FormHelper()
        self.helper.form_method = "post"
        self.helper.template_pack = "studio"

        # Disable the default <form> tag; you control it in the template
        # so HTMX attributes (hx-post, hx-target) stay in your hands.
        self.helper.form_tag = False

        self.helper.layout = Layout(
            # Metadata fieldset: terracotta accent (essays section color)
            Fieldset(
                "Metadata",
                "title",
                "slug",
                "date",
                "draft",
                "stage",
                css_class="section-terracotta",
            ),

            # Content fieldset: plain (no section color)
            Fieldset(
                "Content",
                "excerpt",
                "body",
                css_class="",
            ),

            # SEO fieldset: teal accent (informational/secondary)
            Fieldset(
                "SEO & Discovery",
                "description",
                "tags",
                "featured_image",
                css_class="section-teal with-grid",
            ),

            # Composition fieldset: gold accent (structural/architectural)
            Fieldset(
                "Page Composition",
                "composition",
                css_class="section-gold",
            ),
        )


# --------------------------------------------------------------------------
# Pattern for other forms: same approach, different section colors
# --------------------------------------------------------------------------


class BrandFieldNoteForm:
    """
    Pseudocode reference. Apply the same pattern:

    self.helper.layout = Layout(
        Fieldset("Observation", "title", "slug", "date",
                 css_class="section-teal"),         # field notes = teal
        Fieldset("Content", "body", "location"),
        Fieldset("Classification", "tags", "category",
                 css_class="section-teal with-grid"),
    )
    """
    pass


class BrandProjectForm:
    """
    self.helper.layout = Layout(
        Fieldset("Project Details", "title", "slug", "role", "date",
                 css_class="section-gold"),          # projects = gold
        Fieldset("Content", "body", "excerpt"),
        Fieldset("Media", "featured_image", "callout",
                 css_class="section-gold with-grid"),
    )
    """
    pass
